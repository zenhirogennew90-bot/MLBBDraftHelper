# MLBB Draft Helper (overlay) - Langkah 1-2

Overlay bubble yang bisa digeser + panel kecil. Aplikasi hanya membaca layar milikmu sendiri
(langkah berikutnya) dan tidak memakai internet, jaringan game, atau memori game.

## Build APK
1. Instal Android Studio (gratis), pilih **Open** dan arahkan ke folder ini.
2. Tunggu Gradle sync selesai (butuh internet sekali untuk mengunduh dependency).
3. Sambungkan HP (USB debugging aktif) lalu tekan **Run**, atau **Build > Build APK(s)**.
   APK ada di `app/build/outputs/apk/debug/`.

## Cara pakai
1. Buka aplikasi, ketuk **1. Izinkan tampil di atas aplikasi lain**, aktifkan untuk aplikasi ini.
2. Ketuk **2. Nyalakan bubble**. Bubble "DH" muncul dan bisa digeser.
3. Ketuk bubble untuk membuka/menutup panel. Matikan lewat tombol di app atau notifikasi.

## Menambah ikon hero (dipakai di langkah 3)
Simpan potongan ikon hero (PNG, nama = nama hero, mis. `Fanny.png`) di `app/src/main/assets/heroes/`.
Ambil dari screenshot layar draft milikmu sendiri, dengan ukuran potong yang konsisten.

## Peta langkah
1. Bubble + panel (selesai)
2. Screen capture (ini): tombol Scan -> dialog izin -> 1 frame diambil, lalu izin dilepas
3. Detektor hero (OpenCV template matching + koreksi manual)
4. Mesin saran (data hero JSON, logika dari draft helper web)

## Catatan Scan (langkah 2)
- Setiap Scan memunculkan dialog izin rekam layar (aturan Android, terutama 14+). Itu normal.
- Bubble dan panel disembunyikan ~0,25 detik saat capture agar tidak ikut terfoto.
- Hanya satu frame yang diambil, lalu MediaProjection dihentikan.
- Hasil tersimpan di memori (`data/ScanStore.last`) untuk detektor di langkah 3.
