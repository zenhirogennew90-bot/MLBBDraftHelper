package com.example.mlbbdraft.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/** Mengambil SATU frame layar lewat MediaProjection, lalu melepas semuanya. */
class ScreenCapture(private val ctx: Context) {

    private val handler = Handler(Looper.getMainLooper())

    fun captureOnce(projection: MediaProjection, onDone: (Bitmap?) -> Unit) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        var vd: VirtualDisplay? = null
        var bmp: Bitmap? = null
        var finished = false

        fun finish() {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            runCatching { vd?.release() }
            runCatching { reader.close() }
            onDone(bmp)
        }

        // Android 14+ mewajibkan callback terdaftar sebelum membuat VirtualDisplay
        projection.registerCallback(object : MediaProjection.Callback() {}, handler)
        vd = projection.createVirtualDisplay(
            "draft-scan", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { bmp = toBitmap(img, w, h) } finally { img.close() }
            finish()
        }, handler)
        handler.postDelayed({ finish() }, 3000) // batas waktu: gagal = null
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * w
        val full = Bitmap.createBitmap(
            w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)
        return if (full.width == w) full else Bitmap.createBitmap(full, 0, 0, w, h)
    }
}
