package com.example.mlbbdraft.ui

import android.content.Context
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.mlbbdraft.R

/** Panel kecil hasil saran (maks 6 baris). */
class PanelView(
    context: Context,
    private val onScan: () -> Unit,
    private val onClose: () -> Unit,
) : LinearLayout(context) {

    private val result: TextView

    init {
        orientation = VERTICAL
        val p = dp(12)
        setPadding(p, p, p, p)
        setBackgroundResource(R.drawable.panel_bg)

        addView(TextView(context).apply {
            text = "Draft Helper"
            textSize = 16f
            setTextColor(Color.parseColor("#E0B252"))
        })
        result = TextView(context).apply {
            text = "Buka layar pemilihan hero, lalu ketuk Scan."
            textSize = 13f
            setTextColor(Color.parseColor("#E8ECF5"))
            setPadding(0, dp(6), 0, dp(8))
            maxLines = 6
        }
        addView(result)

        val row = LinearLayout(context).apply { orientation = HORIZONTAL }
        row.addView(Button(context).apply { text = "Scan"; setOnClickListener { onScan() } })
        row.addView(Button(context).apply { text = "Tutup"; setOnClickListener { onClose() } })
        addView(row)
    }

    fun showResult(lines: List<String>) {
        result.text = lines.take(6).joinToString("\n")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
