package com.example.mlbbdraft.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.mlbbdraft.service.OverlayService

/** Layar awal: memandu izin overlay + notifikasi, lalu menyalakan/mematikan bubble. */
class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnToggle: Button

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "MLBB Draft Helper"
            textSize = 24f
        })
        status = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad) }
        root.addView(status)

        btnOverlay = Button(this).apply {
            text = "1. Izinkan tampil di atas aplikasi lain"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        root.addView(btnOverlay)

        btnToggle = Button(this).apply {
            setOnClickListener { toggleService() }
        }
        root.addView(btnToggle)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toggleService() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(i)
        } else if (Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, i)
        }
        btnToggle.postDelayed({ refresh() }, 300)
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        btnOverlay.isEnabled = !canDraw
        btnToggle.isEnabled = canDraw
        btnToggle.text = if (OverlayService.running) "Matikan bubble" else "2. Nyalakan bubble"
        status.text = when {
            !canDraw -> "Izin overlay belum aktif. Ketuk tombol 1, lalu aktifkan untuk aplikasi ini."
            OverlayService.running -> "Bubble aktif. Buka MLBB, bubble akan melayang di atasnya."
            else -> "Izin siap. Ketuk tombol 2 untuk menampilkan bubble."
        }
    }
}
