package com.example.mlbbdraft.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.example.mlbbdraft.R
import com.example.mlbbdraft.data.ScanStore
import com.example.mlbbdraft.ui.BubbleTouchListener
import com.example.mlbbdraft.ui.CaptureRequestActivity
import com.example.mlbbdraft.ui.PanelView

/** Foreground service yang memegang bubble + panel overlay dan menjalankan scan. */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_CAPTURE = "capture"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        private const val ACTION_STOP = "stop"
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: PanelView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var panelOpen = false
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground(withProjection = false)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        addBubble()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_CAPTURE -> {
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (data != null) doCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        runCatching { bubble?.let { wm.removeView(it) } }
        runCatching { panel?.let { if (panelOpen) wm.removeView(it) } }
        bubble = null; panel = null
        super.onDestroy()
    }

    // ---- Scan ----

    /** Dipanggil tombol Scan: minta izin rekam layar (dialog sistem). */
    private fun requestScan() {
        startActivity(
            Intent(this, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun doCapture(resultCode: Int, data: Intent) {
        // Android 14+: tipe mediaProjection baru boleh dipakai SETELAH izin diberikan
        startAsForeground(withProjection = true)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val projection = runCatching { mpm.getMediaProjection(resultCode, data) }.getOrNull()
        if (projection == null) { panel?.showResult(listOf("Gagal memulai capture.")); return }

        setOverlayVisible(false)
        main.postDelayed({
            ScreenCapture(this).captureOnce(projection) { bmp ->
                runCatching { projection.stop() }
                setOverlayVisible(true)
                ScanStore.last = bmp
                panel?.showResult(
                    if (bmp != null) listOf("Tangkapan layar OK (${bmp.width}x${bmp.height}).",
                        "Detektor hero aktif di langkah 3.")
                    else listOf("Tangkapan gagal. Coba Scan lagi.")
                )
            }
        }, 250) // beri waktu bubble/panel hilang dari layar
    }

    private fun setOverlayVisible(visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.INVISIBLE
        bubble?.visibility = v
        panel?.visibility = v
    }

    // ---- Overlay ----

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addBubble() {
        val size = dp(52)
        bubbleParams = overlayParams(size, size).apply { x = dp(8); y = dp(200) }
        val v = TextView(this).apply {
            text = "DH"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#0E1320"))
            setBackgroundResource(R.drawable.bubble_bg)
            contentDescription = "Buka panel Draft Helper"
        }
        v.setOnTouchListener(BubbleTouchListener(wm, bubbleParams, ::placePanel, ::togglePanel))
        wm.addView(v, bubbleParams)
        bubble = v

        panelParams = overlayParams(dp(240), WindowManager.LayoutParams.WRAP_CONTENT)
        panel = PanelView(this, onScan = ::requestScan, onClose = ::togglePanel)
    }

    private fun togglePanel() {
        val p = panel ?: return
        if (panelOpen) {
            wm.removeView(p)
        } else {
            placePanel()
            wm.addView(p, panelParams)
        }
        panelOpen = !panelOpen
    }

    private fun placePanel() {
        val dm = resources.displayMetrics
        val b = bubbleParams
        panelParams.x = b.x.coerceAtMost(dm.widthPixels - dp(240))
        val below = b.y + dp(56)
        panelParams.y = if (below + dp(180) > dm.heightPixels) (b.y - dp(180)).coerceAtLeast(0) else below
        if (panelOpen) panel?.let { wm.updateViewLayout(it, panelParams) }
    }

    private fun startAsForeground(withProjection: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay Draft Helper", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Draft Helper aktif")
            .setContentText("Ketuk Matikan untuk menghapus bubble")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(null, "Matikan", stop).build())
            .setOngoing(true)
            .build()

        when {
            Build.VERSION.SDK_INT >= 34 -> {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                startForeground(NOTIF_ID, n, type)
            }
            Build.VERSION.SDK_INT >= 29 && withProjection ->
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else -> startForeground(NOTIF_ID, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
