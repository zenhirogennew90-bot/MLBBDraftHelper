package com.example.mlbbdraft.ui

import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager

/** Geser bubble; ketukan singkat (tanpa geser) memanggil [onTap]. */
class BubbleTouchListener(
    private val wm: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val onMoved: () -> Unit,
    private val onTap: () -> Unit,
) : View.OnTouchListener {

    private var startX = 0
    private var startY = 0
    private var downRawX = 0f
    private var downRawY = 0f
    private var dragging = false

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(v.context).scaledTouchSlop
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = params.x; startY = params.y
                downRawX = e.rawX; downRawY = e.rawY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!dragging && (dx * dx + dy * dy) > slop * slop) dragging = true
                if (dragging) {
                    val dm = v.resources.displayMetrics
                    params.x = (startX + dx).toInt().coerceIn(0, dm.widthPixels - v.width)
                    params.y = (startY + dy).toInt().coerceIn(0, dm.heightPixels - v.height)
                    wm.updateViewLayout(v, params)
                    onMoved()
                }
            }
            MotionEvent.ACTION_UP -> if (!dragging) { v.performClick(); onTap() }
        }
        return true
    }
}
