package com.example.mlbbdraft.data

import android.graphics.Bitmap

/** Menyimpan tangkapan layar terakhir di memori untuk dipakai detektor (langkah 3). */
object ScanStore {
    @Volatile var last: Bitmap? = null
}
