package com.example.mlbbdraft.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.mlbbdraft.service.OverlayService

/** Activity transparan: tampilkan dialog izin rekam layar, kirim hasilnya ke service. */
class CaptureRequestActivity : ComponentActivity() {

    private val launcher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                startService(
                    Intent(this, OverlayService::class.java)
                        .setAction(OverlayService.ACTION_CAPTURE)
                        .putExtra(OverlayService.EXTRA_CODE, res.resultCode)
                        .putExtra(OverlayService.EXTRA_DATA, res.data)
                )
            } else {
                Toast.makeText(this, "Scan dibatalkan", Toast.LENGTH_SHORT).show()
            }
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        launcher.launch(mpm.createScreenCaptureIntent())
    }
}
